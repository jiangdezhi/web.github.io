<?php
	the_posts_pagination( array( 'prev_text' => __( '上一页', 'boke-1' ), 'next_text' => __( '下一页', 'boke-1' ) ) );
?>